// document.addEventListener('DOMContentLoaded', function() {
    // Simulamos una solicitud al servidor para obtener la URL de la imagen de fondo
   // fetch('json/getImageURL.json')
     //   .then(response => response.json())
       // .then(data => {
            // Actualiza la imagen de fondo usando la URL obtenida del JSON
         //   document.querySelector('.background-container::before').style.backgroundImage = `url('${data.backgroundImageUrl}')`;
        //})
        //.catch(error => console.error('Error fetching image URL:', error));
//});

//    ESO ANTERIOR ES CON JSON Y ACÁ VA PURO JS //

document.addEventListener('DOMContentLoaded', function() {
    const backgroundImageUrl = 'img/fondo.jpg'; // Aquí pones la ruta de tu imagen

    // Selecciona el contenedor y establece la imagen de fondo
    const container = document.querySelector('.background-container');
    container.style.backgroundImage = `url('${backgroundImageUrl}')`;
});

