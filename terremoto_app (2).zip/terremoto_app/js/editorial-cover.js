// Información de las notas (texto e imágenes)
const notes = [
    {
        background: 'img/01.png',
        mainText: 'EDITORIAL ',
        subTexts: ['TRAICIONAR A NUESTRA PROPIA LENGUA', '19 DE AGOSTO DE 2024', 'MEXICO CITY'],
        floatImages: ['img/04.jpg', 'img/05.jpg']
    },
    {
        background: 'img/02.jpg',
        mainText: 'EDITORIAL ',
        subTexts: ['CARTOGRAFÍA SENTIMENTAL DE LA BRUTALIZACIÓN EN CURSO', '19 DE AGOSTO DE 2024', 'MEXICO CITY'],
        floatImages: ['img/06.png', 'img/07.jpg']
    },
    {
        background: 'img/03.jpg',
        mainText: 'EDITORIAL ',
        subTexts: ['DE LA OCUPACIÓN CENITAL AL TESTOMINIO NADRIAL', '19 DE AGOSTO DE 2024', 'MEXICO CITY'],
        floatImages: ['img/01.png', 'img/02.jpg']
    }
];

let currentIndex = 0;

// Cambia la nota según el índice
function changeNote(index) {
    const note = notes[index];
    document.getElementById('background').style.backgroundImage = `url(${note.background})`;
    document.getElementById('mainText').innerText = note.mainText;
    document.getElementById('subText1').innerText = note.subTexts[0];
    document.getElementById('subText2').innerText = note.subTexts[1];
    document.getElementById('subText3').innerText = note.subTexts[2];
    document.getElementById('floatImg1').src = note.floatImages[0];
    document.getElementById('floatImg2').src = note.floatImages[1];
    
    // Actualizar el estado de los botones
    updateButtonState(index);
}

// Función para cambiar la nota con los botones
function changeNoteByButton(index) {
    currentIndex = index;
    changeNote(index);
}

// Cambia la nota según el scroll en la primera sección
window.addEventListener('scroll', () => {
    const scrollPosition = window.scrollY;
    const windowHeight = window.innerHeight;

    // Cambiar solo si estamos dentro de la primera sección
    if (scrollPosition < 3 * windowHeight) {
        const index = Math.min(Math.floor(scrollPosition / windowHeight), notes.length - 1);
        if (index !== currentIndex) {
            currentIndex = index;
            changeNote(index);
        }
    }
});

// Actualiza el estado visual de los botones
function updateButtonState(activeIndex) {
    for (let i = 0; i < notes.length; i++) {
        const button = document.getElementById(`button${i}`);
        button.classList.toggle('active', i === activeIndex);
    }
}

// Crear los botones dinámicamente con todos los subTexts
function createButtons() {
    const buttonContainer = document.getElementById('buttonContainer');
    notes.forEach((note, index) => {
        const button = document.createElement('button');
        
        // Añadir subTexts en el botón
        button.innerHTML = `
            <strong>${note.subTexts[0]}</strong><br>
            ${note.subTexts[1]}<br>
            ${note.subTexts[2]}
        `;
        
        button.id = `button${index}`;
        button.onclick = () => changeNoteByButton(index);
        buttonContainer.appendChild(button);
    });
}

// Inicializar
createButtons();
changeNote(0);